"""
Streamlit UI for the AI Research Agent.

Run locally with:
    streamlit run app.py
"""

import streamlit as st

from agent import run_research

st.set_page_config(page_title="AI Research Agent", page_icon="🔎", layout="centered")

st.title("🔎 AI Research Agent")
st.caption(
    "A single CrewAI agent that searches the web (DuckDuckGo) and writes "
    "a report, powered by Groq (openai/gpt-oss-120b)."
)

# --- Sidebar: API key -------------------------------------------------------
with st.sidebar:
    st.header("Settings")

    # If a GROQ_API_KEY secret exists (e.g. on Streamlit Cloud), pre-fill it
    # so the user doesn't have to paste it in every time.
    default_key = ""
    try:
        default_key = st.secrets.get("GROQ_API_KEY", "")
    except Exception:
        pass

    groq_api_key = st.text_input(
        "Groq API Key",
        type="password",
        value=default_key,
        help="Get a free key at https://console.groq.com/keys",
    )

    st.markdown("---")
    st.markdown(
        "**Stack:** [CrewAI](https://www.crewai.com/) (single agent) · "
        "[Groq](https://groq.com/) LLM · DuckDuckGo search (free, no key)"
    )

# --- Main form ---------------------------------------------------------------
topic = st.text_input(
    "Enter a research topic",
    placeholder="e.g. The impact of AI agents on software jobs in 2026",
)

run_clicked = st.button("Run Research", type="primary")

if run_clicked:
    if not groq_api_key:
        st.error("Please enter your Groq API key in the sidebar first.")
    elif not topic.strip():
        st.error("Please enter a research topic.")
    else:
        with st.spinner("Researching... this can take a minute or two ⏳"):
            try:
                report = run_research(topic=topic.strip(), groq_api_key=groq_api_key)
            except Exception as exc:
                st.error(f"Something went wrong while running the agent:\n\n{exc}")
            else:
                st.success("Done! Here is your report:")
                st.markdown(report)
                st.download_button(
                    label="⬇️ Download report as Markdown",
                    data=report,
                    file_name="research_report.md",
                    mime="text/markdown",
                )
