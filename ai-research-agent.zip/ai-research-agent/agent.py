"""
Defines the single-agent CrewAI research crew.

Agent  -> "Senior Research Analyst": searches the web and writes a report.
Task   -> "Research and report" on whatever topic the user gives us.
Crew   -> Runs just that one agent/task, sequentially.
"""

from crewai import Agent, Task, Crew, Process, LLM

from tools.search_tool import DuckDuckGoSearchTool

# The Groq model requested: OpenAI's open-weight GPT-OSS 120B, served on Groq.
# Groq exposes an OpenAI-compatible API, so we point CrewAI's built-in
# "openai" provider at Groq's base_url instead of relying on the optional
# litellm fallback package. This keeps the dependency list small.
GROQ_MODEL = "openai/gpt-oss-120b"
GROQ_BASE_URL = "https://api.groq.com/openai/v1"


def build_crew(topic: str, groq_api_key: str) -> Crew:
    """Builds (but does not run) the research crew for a given topic."""

    llm = LLM(
        model=GROQ_MODEL,
        api_key=groq_api_key,
        base_url=GROQ_BASE_URL,
        temperature=0.3,
    )

    search_tool = DuckDuckGoSearchTool()

    researcher = Agent(
        role="Senior Research Analyst",
        goal=(
            f"Research the topic '{topic}' thoroughly using web search, and "
            "produce an accurate, well-organized, well-sourced report."
        ),
        backstory=(
            "You are an experienced research analyst. You are skilled at "
            "forming good search queries, verifying facts across multiple "
            "sources, and writing clear, well-structured reports for a "
            "general audience. You never make up facts or sources."
        ),
        tools=[search_tool],
        llm=llm,
        verbose=True,
        allow_delegation=False,
    )

    research_task = Task(
        description=(
            f"Research the topic: '{topic}'.\n\n"
            "Steps to follow:\n"
            "1. Use the DuckDuckGo Web Search tool with several different, "
            "specific search queries to gather up-to-date information, "
            "facts, and figures about the topic.\n"
            "2. Where possible, cross-check important facts across more "
            "than one source.\n"
            "3. Identify key sub-topics, recent developments, and any "
            "notable disagreements or differing viewpoints.\n"
            "4. Write a well-structured report in Markdown with these "
            "sections: '# Title', '## Introduction', '## Key Findings' "
            "(as bullet points), '## Analysis', '## Conclusion', and "
            "'## Sources' (a list of the URLs you used).\n\n"
            "If you are not confident about a fact, say so explicitly "
            "instead of guessing. Do not invent sources."
        ),
        expected_output=(
            "A complete, well-structured Markdown report on the topic, "
            "including headings, bullet points for key findings, and a "
            "Sources section with real URLs found via search."
        ),
        agent=researcher,
    )

    return Crew(
        agents=[researcher],
        tasks=[research_task],
        process=Process.sequential,
        verbose=True,
    )


def run_research(topic: str, groq_api_key: str) -> str:
    """Builds the crew and runs it, returning the final report as a string."""
    crew = build_crew(topic=topic, groq_api_key=groq_api_key)
    result = crew.kickoff()
    return str(result)
