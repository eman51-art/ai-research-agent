# 🔎 AI Research Agent (CrewAI + Groq + Streamlit)

A beginner-friendly single-agent AI research tool:
1. You type in a topic.
2. A **CrewAI** agent searches the web with **DuckDuckGo** (free, no API key).
3. The agent writes a structured Markdown report using **Groq's
   `openai/gpt-oss-120b`** model (very fast, free tier available).
4. Everything is shown in a simple **Streamlit** web app.

---

## 1. Project structure

```
ai-research-agent/
├── app.py                 # Streamlit UI (what the user sees)
├── agent.py                # CrewAI agent, task, and crew definition
├── tools/
│   ├── __init__.py
│   └── search_tool.py      # Free DuckDuckGo search tool for the agent
├── requirements.txt        # Python dependencies
├── runtime.txt              # Python version for Streamlit Cloud
├── .env.example             # Template for your local secret key
├── .gitignore
└── README.md
```

---

## 2. Get a free Groq API key

1. Go to https://console.groq.com/keys
2. Sign up / log in (free).
3. Click **Create API Key**, copy it. It looks like `gsk_...`.
4. Keep it secret — never commit it to GitHub.

---

## 3. Run it on your own computer (recommended first step)

You need **Python 3.10 or 3.11** installed.

```bash
# 1. Go into the project folder
cd ai-research-agent

# 2. Create a virtual environment (keeps dependencies isolated)
python -m venv venv

# 3. Activate it
# On Windows:
venv\Scripts\activate
# On Mac/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Run the app
streamlit run app.py
```

A browser tab will open automatically (usually `http://localhost:8501`).
Paste your Groq API key into the sidebar, type a topic, and click
**Run Research**.

> You don't strictly need the `.env` file for local testing since the app
> lets you paste the key into the sidebar. `.env` / `python-dotenv` is
> there in case you later want to load the key automatically instead of
> typing it each time.

---

## 4. Push the project to GitHub

If you're new to Git, here's the simplest path:

```bash
cd ai-research-agent

# Initialize a git repository
git init

# Add all files (the .gitignore already excludes secrets)
git add .

# Make your first commit
git commit -m "Initial commit: AI research agent"

# Create a new EMPTY repository on github.com (no README/license there),
# then copy the URL it gives you and run:
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git branch -M main
git push -u origin main
```

Double-check on GitHub.com that your `.env` file (if you made one) is
**not** in the repo — only `.env.example` should be there.

---

## 5. Deploy on Streamlit Community Cloud

1. Go to https://share.streamlit.io and sign in with GitHub.
2. Click **New app**.
3. Pick your repository and branch (`main`).
4. Set **Main file path** to `app.py`.
5. Before/after deploying, open **Advanced settings → Secrets** and add:
   ```toml
   GROQ_API_KEY = "gsk_your_real_key_here"
   ```
   This is how the app pre-fills the key in the sidebar securely, without
   it ever being in your code or GitHub repo. (Users can still paste in
   their own key instead if you leave the field editable, which the app
   does by default.)
6. Click **Deploy**. First build takes a few minutes (installing
   `crewai` pulls in a fair number of dependencies — this is normal).
7. Once it's live, you'll get a public URL like
   `https://your-app-name.streamlit.app`.

---

## 6. How the code fits together (quick tour)

- **`tools/search_tool.py`** — A `BaseTool` subclass CrewAI agents can call.
  It wraps the `ddgs` library (the current DuckDuckGo search package) and
  returns the top 5 results as plain text (title, snippet, link).

- **`agent.py`** — Defines:
  - `LLM(model="openai/gpt-oss-120b", api_key=..., base_url="https://api.groq.com/openai/v1")`
    — Groq exposes an OpenAI-compatible API, so we use CrewAI's built-in
    `openai` provider but point it at Groq's servers instead of OpenAI's.
    This avoids needing the optional `litellm` package just to reach Groq.
  - One `Agent` ("Senior Research Analyst") with the search tool attached.
  - One `Task` describing exactly how to research and format the report.
  - One `Crew` (sequential process, single agent) that runs the task.

- **`app.py`** — A small Streamlit form: text input for the topic, a
  sidebar for the API key, a button to run the crew, and a download
  button for the finished Markdown report.

---

## 7. Common beginner issues

| Problem | Likely fix |
|---|---|
| `ModuleNotFoundError: No module named 'ddgs'` | Run `pip install -r requirements.txt` again inside your activated virtual environment. |
| App says "Please enter your Groq API key" | Paste your key (starts with `gsk_`) into the sidebar field. |
| Search tool returns "No results found" | DuckDuckGo can rate-limit rapid repeated searches — wait a few seconds and try again. |
| Streamlit Cloud build fails / times out | Re-deploy (it sometimes needs a second try); make sure `requirements.txt` and `runtime.txt` are committed. |
| Agent's report looks incomplete or cuts off | Try a narrower/more specific topic, or re-run — LLM output can vary. |

---

## 8. Ideas to extend this later

- Add a second agent (e.g. an "Editor" agent that reviews and polishes
  the Research Analyst's draft) — this is your natural next step from
  single-agent to multi-agent CrewAI.
- Let the user pick the Groq model from a dropdown.
- Cache reports so re-running the same topic doesn't re-search.
- Export to PDF instead of just Markdown.
