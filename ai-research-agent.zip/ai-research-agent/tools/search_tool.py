"""
A free, no-API-key web search tool for our CrewAI agent, built on top of
DuckDuckGo via the `ddgs` package (the current, maintained name of the
library formerly known as `duckduckgo-search`).
"""

from typing import Type

from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from ddgs import DDGS


class DuckDuckGoSearchInput(BaseModel):
    """Input schema for the DuckDuckGo search tool."""
    query: str = Field(..., description="The search query to look up on the web.")


class DuckDuckGoSearchTool(BaseTool):
    name: str = "DuckDuckGo Web Search"
    description: str = (
        "Searches the web using DuckDuckGo and returns the top results "
        "(title, short summary, and source link) for a given query. "
        "Use this whenever you need current facts, news, statistics, or "
        "sources to support your research. Call it multiple times with "
        "different, specific queries to cover a topic well."
    )
    args_schema: Type[BaseModel] = DuckDuckGoSearchInput

    def _run(self, query: str) -> str:
        try:
            results = DDGS().text(query, max_results=5)
        except Exception as exc:  # network hiccups, rate limits, etc.
            return f"Search failed for query '{query}': {exc}"

        if not results:
            return f"No results found for query: '{query}'."

        formatted = []
        for i, r in enumerate(results, start=1):
            title = r.get("title", "No title")
            body = r.get("body", "").strip()
            link = r.get("href", "")
            formatted.append(f"{i}. {title}\n   {body}\n   Source: {link}")

        return "\n\n".join(formatted)
